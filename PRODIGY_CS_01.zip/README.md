# Task-01: Caesar Cipher

**Prodigy Infotech | Cyber Security Internship**  
**Track Code:** PRODIGY_CS_01  
**Task Title:** Implement Caesar Cipher

## 🔐 Objective
Create a Python-based Caesar Cipher encryption and decryption program.

## 📌 Features
- Encrypt and decrypt messages
- Handles upper/lowercase characters
- Ignores non-alphabetic characters (e.g., punctuation, numbers)
- User-friendly terminal interface

## 📁 Files Included
- `Caesar Cipher Program in Python`: Main script file
- `README.md`: Project description and instructions
- `LICENSE.md`: Open-source MIT License
- `.gitignore`: Ignored files setup

## 🚀 How to Run
```bash
python "Caesar Cipher Program in Python"
```

Follow prompts to encrypt or decrypt any message.
