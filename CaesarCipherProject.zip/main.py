def encrypt(text, shift):
    result = ""
    for char in text:
        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')
            result += chr((ord(char) - base + shift) % 26 + base)
        else:
            result += char
    return result

def decrypt(text, shift):
    return encrypt(text, -shift)

def main():
    print("Caesar Cipher Encryption/Decryption")
    choice = input("Choose (E)ncrypt or (D)ecrypt: ").strip().upper()
    text = input("Enter your message: ")
    shift = int(input("Enter the shift value: "))

    if choice == 'E':
        encrypted = encrypt(text, shift)
        print("Encrypted Message:", encrypted)
    elif choice == 'D':
        decrypted = decrypt(text, shift)
        print("Decrypted Message:", decrypted)
    else:
        print("Invalid choice.")

if __name__ == "__main__":
    main()
